# Audio Metadata Cross-check

Status: COMPLETE FOR OVERLORD I DIRECT GNARL REFERENCES

The active working corpus does not retain MP3 payloads.

A filename-only index was generated for all 9,693 supplied MP3 files.

For the 379 unique Overlord I localization references directly routed through `ShowMinionMasterText(...)`:

- exact MP3 filename matches: 365
- references without an exact MP3 filename match: 14

This means the audio files are not required as an active data payload for the majority of direct Gnarl-reference bookkeeping. The sequence filename itself can be retained as metadata while the immutable source archives preserve the original audio if later review is necessary.

Unmatched refs:

```text
D0_TUT_MM@105@30
D0_TUT_MM@106@55
D0_TUT_MM@106@60
D0_TUT_MM@108@40
D1SD2_HalflingHomes@106@10
D1_SD1_TheMoistHollows@100@10
D1_SD2_HalflingHomes@203@20
D1_SD4_Castle Spree@304@10
D3_SD1_TheMoistHollows@101@10
D3_SD1_TheMoistHollows@104@10
D4_SD3_TheBrewery@101@50
Warrior_In_Spree@110@10
Warrior_In_Spree@110@20
Warrior_In_Spree@110@30
```
