# 8LD Decoder Research

Status: ACTIVE TECHNICAL RESEARCH
Date: 2026-09-11

## Decision on MP3 material

MP3 voice files are removed from the ACTIVE working corpus.

They are not deleted from the two immutable master archives.

Reason:
- Minecraft quest implementation requires text, state, speaker identity, and quest logic rather than original audio.
- Map scripts and decoded localization should normally provide those facts more directly.
- Audio remains useful only as secondary evidence for delivery, pronunciation, or unresolved speaker attribution.

## Confirmed 8LD facts

1. Supplied localization files begin with the ASCII magic `M8LD`.
2. The remaining payload is binary and not recoverable by ordinary string extraction.
3. Historical resource-extraction discussion identified the format as encrypted.
4. Multiple independent Overlord II localization guides document successful `8LD -> XML` conversion using `O2Tools`.
5. Age of Wonders III, also by Triumph Studios, uses the same `.8ld` localization family and likewise supports conversion to editable XML.
6. A current localization-tool developer publicly states that they have written an Overlord 1/2 `.8ld` packer/unpacker, but that utility is not distributed publicly.
7. No untrusted historical executable has been run against the corpus.

## Current position

The format is therefore not an unknown opaque container. It is a known-decodable Triumph localization format for which the public implementation trail is fragmented.

The preferred solution remains a transparent local decoder rather than depending permanently on an old binary.

## Next technical routes

Priority A:
Recover enough information about O2Tools/TotyaConv or an equivalent implementation to document the binary transform.

Priority B:
Use known Triumph XML localization schema and paired source examples to derive the format.

Priority C:
If necessary, reverse engineer the game's own language loader from an original Overlord/Overlord II executable.

Priority C would justify a dedicated code repository because it becomes a reproducible reverse-engineering tool rather than a one-off lore extraction script.

## Validation target

First proof target: `Tower_Awakening.8ld`.

A successful decoder must:
- produce structured text rows;
- preserve sequence IDs used by the Tower map;
- contain entries matching direct `ShowMinionMasterText(...)` references;
- round-trip or structurally agree with known source references;
- avoid inventing missing text.
