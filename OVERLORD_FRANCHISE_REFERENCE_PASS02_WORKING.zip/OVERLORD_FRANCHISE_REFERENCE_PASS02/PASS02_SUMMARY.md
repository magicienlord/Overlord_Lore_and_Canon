# Pass 02 Working Summary

Status: ACTIVE / PARTIAL COMPLETE
Date: 2026-09-11

The active lore corpus has been reduced to non-audio evidence while preserving audio inside the immutable master archives.

Generated primary-source ledgers:
- 87 unique Overlord I internal quest IDs
- 590 raw quest-state function calls
- 469 direct Gnarl/Minion Master dialogue calls
- 379 unique direct Gnarl localization references

The `.8ld` decoder remains the main technical blocker to converting those references into exact English dialogue text.
