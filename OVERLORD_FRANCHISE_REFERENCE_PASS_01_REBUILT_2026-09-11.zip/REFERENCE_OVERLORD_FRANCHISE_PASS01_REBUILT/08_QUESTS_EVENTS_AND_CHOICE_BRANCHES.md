# OVERLORD Franchise Quest and Event Source Map

Status: REFERENCE EVIDENCE, PRELIMINARY

Rebuilt: 2026-09-11

This file maps primary-source material for reconstruction of original Overlord quest logic. It does not import original quests into OVERLORD REIGN.

## 1. Overlord I base campaign

The master set now contains the base campaign language tables, matching English audio, and the complete supplied base map set.

Major language groups include:

```text
D1_MAIN through D5_MAIN
D1_AMBIENT
D3_AMBIENT
D1_SD1 through D4_SD5
Throneroom_Intro
Tower_Awakening
Tower_GeneralMessages
Tower_HeartIntro
Tower_JewelCaptured
Tower_MistressChoice
Tower_PrivateQuarters
Tower_SpawningPit
Tower_Dungeon
Tower_Forge
Tower_ThroneRoomMisc
Tower_Titles
Warrior_In_Heavens_Peak
Warrior_In_Spree
End_Tower_Battle_Narrative
Minion - General Speech
```

Across the 30 non-multiplayer base maps:

- recognized quest-state calls: 590
- unique internal quest IDs: 87
- localization-reference occurrences: 2,787
- unique localization references: 1,825

Examples of internal quest IDs directly present in source scripts include:

```text
D1_FINDHEAVENSPEAK
D1_WORLDSTONE
D1_TRAITORS_FATE
D2_FINDGOLDENHALLS
D2_GROVE
D3_PLAGUE
D3_SUCCUBUS
D3_WILLIAM
D4_MINE
D4_QUARRY
D4_BREWERY
D4_ARCANIUM
D5_FINDJEWEL
D5_CAPTUREJEWEL1
D5_CAPTUREJEWEL2
TOWER_MINIONS
TOWER_SPELLS
```

These are developer-facing identifiers until corroborated by localization.

Readable map labels correlate source groups with places and populations such as `The Tower`, `The Mellow Hills`, `Evernight Forest`, `Heaven's Peak`, `Spree Villagers`, `Refugees`, `Fallen Knights`, `Blue Minions NPC`, and `Skull Tribe`.

## 2. Raising Hell

The master set contains all eight supplied `EXP_*` language tables, 487 `EXP_*` English voice files, and 14 dedicated expansion maps.

Across those maps:

- recognized quest-state calls: 651
- unique internal quest IDs: 109
- localization-reference occurrences: 2,703
- unique localization references: 1,849

The maps preserve extensive base-campaign state as well as expansion state. Expansion-specific reconstruction must therefore distinguish `EXP_*` references from inherited material.

## 3. Overlord II

High-value quest sources include:

```text
Prelude
Becoming_the_Overlord
Hunting_Grounds
Nordberg_Town_Chunk_4
Nordberg_Town_Chunk_6
Nordberg_Sanctuary
Everlight_Gates
Everlight_Jungle
Everlight_Facility
Everlight_Temple
Everlight_Town
Wastelands
Wasteland_Sanctuary
Empire_Heartlands
Empire_Assault
Empire_Arena
Empire_Endbattle
End_Scene
NW_B
NW_F
NW_TR
Tower_Objects
Resources/System_Quests
```

The 26 single-player maps contain:

- localization-reference occurrences: 2,712
- unique localization references: 2,299
- quest-state calls recognized by the Overlord I parser: 25
- unique quest IDs under that parser: 10

The low quest count is a tooling limitation, not a narrative conclusion. Overlord II uses materially different state/event constructs.

## 4. Gnarl attribution available before text decoding

Overlord I map scripts directly call:

```text
ShowMinionMasterText("SOURCE@SEQUENCE@LINE")
```

The base campaign contains 469 such calls representing 379 unique localization references.

Raising Hell contains 128 unique expansion-specific `EXP_*` Minion Master references.

This gives us speaker ownership for hundreds of Gnarl lines without guessing from audio.

Overlord II does not expose the same simple call pattern, so its line-level speaker attribution remains pending a dedicated parser or decoded localization correlation.

## 5. Reconstruction ledger

Each original quest/event should eventually record:

```text
SOURCE GAME
SOURCE ARCHIVE
SOURCE MAP
SOURCE LANGUAGE FILE
LOCALIZATION REFERENCE
AUDIO FILE
SPEAKER
LOCATION
PRECONDITION
QUEST ENABLE EVENT
OBJECTIVE / EVENT
PLAYER CHOICE
BRANCH CONDITION
QUEST COMPLETION EVENT
WORLD STATE CHANGE
REWARD / PROGRESSION EFFECT
FOLLOW-UP QUEST
SOURCE EVIDENCE CLASS
CONFIDENCE
```

## 6. Recommended extraction order

1. `Tower_Awakening.8ld` against `Maps/Tower/Tower.omp`.
2. `D1_MAIN.8ld` as the first complete quest-graph proof of concept.
3. `Tower_GeneralMessages.8ld`, `Tower_HeartIntro.8ld`, and `End_Tower_Battle_Narrative.8ld`.
4. The eight `EXP_*` Raising Hell files.
5. Overlord II `Resources/System_Quests.8ld`.
6. `Becoming_the_Overlord.8ld` and `NW_TR.8ld`.
7. A dedicated Overlord II state extractor.
