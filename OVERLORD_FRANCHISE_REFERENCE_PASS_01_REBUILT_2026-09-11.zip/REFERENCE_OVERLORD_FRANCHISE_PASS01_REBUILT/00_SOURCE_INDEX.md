# OVERLORD Franchise Primary Source Index

Status: REFERENCE EVIDENCE, NOT OVERLORD REIGN CANON

Rebuilt: 2026-09-11

This rebuilt Pass 01 treats both supplied archives as the master primary-source set and supersedes the earlier single-archive inventory.

## 1. Master archives

### Overlord I master archive

- `Overlord 1.zip`
- Size: 181,625,566 bytes (173.21 MiB)
- SHA-256: `4ede2c9b9ea64f358d4646c859a50aa45db76b3a090e7c23eefd1c8557225ce0`
- Raw files: 2,543

This archive is authoritative for the supplied Overlord I language/audio branch and base-game maps. It supplies the base campaign `.8ld` files that were missing from the first pass.

### Overlord II / Raising Hell archive

- `Overlord_Quests_Lore_Ressources.zip`
- Size: 483,343,455 bytes (460.95 MiB)
- SHA-256: `2fc9abaaebf1b64a5b03f665c76d54d9bfce72890e0344fbfddf2a7ec433349f`
- Raw files: 7,353

This archive supplies Overlord II language/audio/maps, dedicated Raising Hell maps, both official US PC manuals, and a distinct Overlord I Tower map variant.

## 2. Reconciliation

The first archive's `Overlord_1_Language` branch and `Overlord 1.zip` share 2,465 logical paths.

- Exact byte-for-byte duplicates: 2,463
- Same-path files with different content: 2
- Files added by `Overlord 1.zip` relative to that old branch: 78

The two same-path differences are:

```text
Language/Apps/Config.8ld
Language/Apps/Launcher.8ld
```

They are application/configuration language files, not campaign narrative files.

The new archive adds the missing base-game `.8ld` layer and base maps. One older `Overlord_1_Map/Tower/Tower.omp` in the first archive differs from the new base `Maps/Tower/Tower.omp`; both are retained as source variants.

## 3. Selected master corpus

After deduplicating the overlapping Overlord I branch, the working master corpus contains 7,431 selected files.

### File types

- `.mp3`: 7,242
- `.8ld`: 96
- `.omp`: 81
- `.ttf`: 6
- `.dat`: 2
- `.pdf`: 2
- `.env`: 1
- `.txt`: 1

`MASTER_SOURCE_MANIFEST.json` records the selected file provenance, size, and SHA-256 digest.

## 4. Source-evidence classes

- `PRIMARY-TEXT`: original game language data once decoded.
- `PRIMARY-AUDIO`: original English voice recordings.
- `PRIMARY-IMPLEMENTATION`: `.omp` scripts, quest states, triggers, aliases, groups, and world-state logic.
- `PRIMARY-MANUAL`: official published manual material.
- `STRUCTURAL-METADATA`: filenames, directories, and sequence identifiers.
- `UNRESOLVED`: source data present but not yet safely decoded or attributable.

Internal labels and debug comments are implementation evidence, not automatically player-facing lore terminology.

## 5. Overlord I base-game coverage

The previous missing-base-language gap is RESOLVED.

- Combined Overlord I/Raising Hell English MP3s in `Overlord 1.zip`: 2,451
- Non-`EXP_*` base-game MP3s: 1,964
- Base-game narrative `.8ld` files: 40
- Application `.8ld` files: 2
- Base `.omp` maps: 36, including 6 multiplayer maps
- Official Overlord I manual: present in the companion archive

### Base-game narrative `.8ld` files

```text
D1_AMBIENT.8ld
D1_MAIN.8ld
D1_SD1_WorkCamp.8ld
D1_SD2_HalflingHomes.8ld
D1_SD3_MelvinsKitchen.8ld
D1_SD4_Castle Spree.8ld
D2_MAIN.8ld
D2_SD1_TheViridianCaverns.8ld
D2_SD2_SkullTribeDen.8ld
D2_SD3_MotherGoddessTemple.8ld
D3_AMBIENT.8ld
D3_MAIN.8ld
D3_SD1_TheMoistHollows.8ld
D3_SD2_TheSewers.8ld
D3_SD3_TheUnderstreets.8ld
D3_SD4_HalfwayToHeavenInn.8ld
D3_SD5_TheCitadel.8ld
D4_MAIN.8ld
D4_SD1_TheGlitteringMine.8ld
D4_SD2_TempleConstruction.8ld
D4_SD3_TheBrewery.8ld
D4_SD4_TheArcaniumMine.8ld
D4_SD5_TheRoyalHalls.8ld
D5_MAIN.8ld
End_Tower_Battle_Narrative.8ld
Minion - General Speech.8ld
Throneroom_Intro.8ld
Tower_Awakening.8ld
Tower_Dungeon.8ld
Tower_Forge.8ld
Tower_GeneralMessages.8ld
Tower_HeartIntro.8ld
Tower_JewelCaptured.8ld
Tower_MistressChoice.8ld
Tower_PrivateQuarters.8ld
Tower_SpawningPit.8ld
Tower_ThroneRoomMisc.8ld
Tower_Titles.8ld
Warrior_In_Heavens_Peak.8ld
Warrior_In_Spree.8ld
```

The 30 non-multiplayer base maps expose:

- 590 recognized quest-state calls
- 87 unique internal quest IDs
- 2,787 localization-reference occurrences
- 1,825 unique localization references
- 469 direct `ShowMinionMasterText(...)` calls
- 379 unique Minion Master localization references

## 6. Overlord: Raising Hell coverage

- `EXP_*` English MP3s: 487
- `EXP_*` `.8ld` files: 8
- Dedicated Raising Hell maps: 14

The 14 expansion maps expose:

- 651 recognized quest-state calls
- 109 unique internal quest IDs
- 2,703 localization-reference occurrences
- 1,849 unique localization references
- 346 Minion Master calls
- 308 unique Minion Master refs
- 128 unique expansion-specific `EXP_*` Minion Master refs

The expansion maps also retain base-campaign state, so `EXP_*` namespace separation is required during analysis.

## 7. Overlord II coverage

- English MP3s: 4,791
- `.8ld` files: 46
- `.omp` maps: 30, including 4 multiplayer maps
- Official Overlord II manual: present

High-value language files include:

```text
Prelude.8ld
Becoming_the_Overlord.8ld
NW_TR.8ld
Tower_Objects.8ld
Wastelands.8ld
End_Scene.8ld
Resources/System_Quests.8ld
Resources/System.8ld
Resources/Minion_Names.8ld
Resources/MinionCausesOfDeath.8ld
```

The 26 single-player maps expose 2,712 localization-reference occurrences and 2,299 unique references. The Overlord I-style quest parser finds only 10 unique quest IDs, showing that Overlord II needs its own state extractor.

## 8. Current extraction state

The `.8ld` files use the `M8LD` binary format and are not plain text. No untrusted historical executable has been run.

The `.omp` maps already provide strong primary implementation evidence linking localization sequence references, quest-state changes, world-state flags, transitions, aliases, cutscene structure, and, in Overlord I, direct Minion Master dialogue calls.

## 9. Master-source policy

1. Preserve both ZIP archives unchanged.
2. Use `MASTER_SOURCE_MANIFEST.json` for provenance.
3. Prefer decoded primary text over memory or secondary summaries.
4. Correlate text with map-state evidence before inferring quest sequence.
5. Correlate text with audio before assigning speakers where the maps do not identify them.
6. Keep franchise evidence separate from OVERLORD REIGN canon status.
7. Never promote internal developer labels into lore terminology without corroboration.
