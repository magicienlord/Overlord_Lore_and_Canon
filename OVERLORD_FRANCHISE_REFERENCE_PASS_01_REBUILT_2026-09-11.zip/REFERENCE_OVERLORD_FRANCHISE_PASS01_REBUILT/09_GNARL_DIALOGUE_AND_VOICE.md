# OVERLORD Franchise Gnarl Dialogue and Voice Reference

Status: REFERENCE EVIDENCE, PRELIMINARY

Rebuilt: 2026-09-11

This file records primary-source evidence useful for future Gnarl writing. It is not an OVERLORD REIGN characterization rewrite.

## 1. Direct line attribution in Overlord I

Across 30 single-player base maps:

- `ShowMinionMasterText(...)` calls: 469
- unique localization refs routed through that function: 379

This is direct implementation evidence that the referenced sequences belong to the Minion Master. Once the matching `.8ld` entries are decoded, those lines can be attributed to Gnarl without voice-identity guessing.

Raising Hell adds 128 unique expansion-specific `EXP_*` Minion Master refs.

## 2. Highest-value Overlord I source groups

```text
Tower_Awakening
Tower_GeneralMessages
Tower_HeartIntro
Tower_JewelCaptured
Tower_MistressChoice
Tower_PrivateQuarters
Tower_SpawningPit
Tower_Dungeon
Tower_Forge
Tower_ThroneRoomMisc
D1_MAIN through D5_MAIN
Warrior_In_Heavens_Peak
Warrior_In_Spree
End_Tower_Battle_Narrative
```

The Tower map also contains direct sequence references and internal `MINION_MASTER` / `Minion - Master` entities.

## 3. Raising Hell

Expansion-specific Gnarl references occur in:

```text
EXP_D1_Abyss
EXP_D2_Abyss
EXP_D3_Abyss
EXP_D4_Abyss
EXP_D5_Abyss
EXP_Endboss_Abyss
EXP_-_SYSTEM_RPK
```

This supports a distinct Raising Hell dialogue corpus.

## 4. Overlord II

Overlord II map data contains extensive Gnarl implementation markers, including internal aliases such as `GNARL`, `MAGIC_GNARL`, `GNARL_HOME`, and `GNARL_TOUR_POINT`, alongside large quantities of narrative localization references.

This is useful for parser development but is not yet sufficient for definitive line-by-line speaker attribution.

Highest-value files include:

```text
Becoming_the_Overlord.8ld
Prelude.8ld
NW_TR.8ld
Tower_Objects.8ld
Wastelands.8ld
Wasteland_Sanctuary.8ld
End_Scene.8ld
Resources/System_Quests.8ld
```

## 5. Manual-supported preliminary voice observations

The two official PC manuals remain part of the master corpus. The preliminary manual-based observations are:

1. Gnarl is presented as the experienced Minion Master, loyal servant, and adviser.
2. He respects the Overlord's rank while remaining comfortable instructing, correcting, and warning him.
3. Tutorial guidance is reframed through conquest, punishment, domination, destruction, Minion management, and evil practice rather than neutral tutorial diction.
4. Cruelty, punishment, Minion casualties, and bad hygiene are often treated as routine administrative or comic material.
5. Competent evil is framed as requiring cunning and effective use of resources, not merely indiscriminate violence.
6. Exposition, tactical instruction, and reinforcement of the Overlord's status are commonly combined.

These remain preliminary until the in-game corpus is decoded.

## 6. Future voice-bible record

For each confirmed Gnarl line:

```text
SOURCE GAME
SOURCE FILE
LOCALIZATION REFERENCE
MAP / SCENE
AUDIO FILE
TEXT
TRIGGER
PLAYER STATE
REGISTER
FUNCTION
TARGET OF MOCKERY / PRAISE
FORM OF ADDRESS
QUEST PURPOSE
NOTES
```

Candidate registers to test from the corpus include ceremonial address, tutorial instruction, quest assignment, reminder, battle warning, praise, mockery, threat framing, Minion management, Tower administration, historical exposition, choice commentary, and correction.

## 7. Immediate targets

```text
Tower_Awakening.8ld
Tower_GeneralMessages.8ld
D1_MAIN.8ld
Tower_HeartIntro.8ld
Tower_Forge.8ld
End_Tower_Battle_Narrative.8ld
EXP_D1_Abyss.8ld
Becoming_the_Overlord.8ld
NW_TR.8ld
```
