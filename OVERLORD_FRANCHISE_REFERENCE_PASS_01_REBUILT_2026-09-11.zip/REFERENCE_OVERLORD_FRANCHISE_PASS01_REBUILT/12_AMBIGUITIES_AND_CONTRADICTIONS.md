# OVERLORD Franchise Source Gaps and Ambiguities

Status: REFERENCE EVIDENCE, NOT OVERLORD REIGN CANON

Rebuilt: 2026-09-11

## GAP-001: Overlord I base-game `.8ld` layer

Status: RESOLVED

`Overlord 1.zip` supplies the base-game language layer that was absent from the earlier Pass 01 package. Source completeness is no longer the blocker for Overlord I text reconstruction.

## GAP-002: `.8ld` decoding

Status: OPEN TECHNICAL GAP

The language files use the `M8LD` binary format and are not plain text.

Impact: exact searchable localization text is not yet available.

Required action: validate or implement a decoder, preserve raw-source provenance, and prove conversion against bounded files before bulk extraction.

## GAP-003: MP3 speaker identity

Status: OPEN

The English voice files are organized by scene and sequence but do not independently establish speaker identity.

Mitigation: correlate audio with map-script routing and decoded language data. Overlord I already provides hundreds of direct Minion Master references through `ShowMinionMasterText(...)`.

## GAP-004: application `.8ld` variants

Status: DOCUMENTED, LOW NARRATIVE IMPORTANCE

Two overlapping same-path files differ between the archives:

```text
Language/Apps/Config.8ld
Language/Apps/Launcher.8ld
```

The rebuilt selected corpus uses the `Overlord 1.zip` versions while preserving both raw archives.

## GAP-005: Overlord I Tower map variant

Status: OPEN PROVENANCE QUESTION

`Overlord_1_Map/Tower/Tower.omp` from the first archive is not byte-identical to `Maps/Tower/Tower.omp` from `Overlord 1.zip`.

Policy: retain both. Use the complete new base archive as the default base-map source and consult the alternate map for version/expansion-state differences.

## GAP-006: Raising Hell maps retain base-game state

Status: OPEN ANALYTICAL REQUIREMENT

Expansion maps include large amounts of inherited base-campaign quest logic and dialogue references.

Policy: use `EXP_*` namespaces and map context to separate expansion-specific material from inherited state.

## GAP-007: Overlord II quest architecture

Status: OPEN TOOLING REQUIREMENT

The Overlord I quest-function parser substantially undercounts Overlord II quest logic.

Policy: build a separate Overlord II extractor and correlate it with `Resources/System_Quests.8ld`.

## GAP-008: internal labels are not automatically lore wording

Status: PERMANENT SOURCE-DISCIPLINE RULE

Map files contain aliases, debug labels, quest IDs, developer comments, and implementation-facing names.

Policy: treat them as `PRIMARY-IMPLEMENTATION` evidence until localization, audio, or official documentation confirms player-facing terminology.

## GAP-009: franchise contradictions not yet adjudicated

Status: NOT YET ASSESSED

Pass 01 inventories and reconciles evidence. It does not yet perform a claim-by-claim canon comparison across Overlord I, Raising Hell, and Overlord II.

Next stage: after language extraction, convert this file into a claim-level ambiguity and contradiction ledger with exact source references.
